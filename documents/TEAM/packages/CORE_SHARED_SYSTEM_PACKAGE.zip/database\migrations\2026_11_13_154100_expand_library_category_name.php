<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('library_categories', function (Blueprint $table) {
            $table->string('name', 120)->change();
        });
    }

    public function down(): void
    {
        Schema::table('library_categories', function (Blueprint $table) {
            $table->string('name', 80)->change();
        });
    }
};
