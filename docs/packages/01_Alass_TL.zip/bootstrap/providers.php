<?php

use App\Providers\AppServiceProvider;
use App\Providers\BranchIsolationServiceProvider;

return [
    AppServiceProvider::class,
    BranchIsolationServiceProvider::class,
];
